import { Execution, Game, Player, PlayerID } from "../../game/Game";

// Fans out an alliance request, tagged with the target federation's id, to
// every current member other than the sponsor (who already counts via the
// pre-existing bilateral alliance that got the requestor sponsored). Each
// request resolves independently through the normal alliance accept/reject
// flow; GameImpl promotes the requestor to a full member once every request
// has landed accepted.
export class FederationJoinRequestExecution implements Execution {
  constructor(
    private readonly requestor: Player,
    private readonly sponsorID: PlayerID,
  ) {}

  init(mg: Game, ticks: number): void {
    if (!mg.hasPlayer(this.sponsorID)) {
      console.warn(
        `[FederationJoinRequestExecution] sponsor ${this.sponsorID} not found`,
      );
      return;
    }
    const sponsor = mg.player(this.sponsorID);
    if (!this.requestor.canRequestFederation(sponsor)) {
      console.warn(
        `[FederationJoinRequestExecution] ${this.requestor.id()} cannot request to join ${sponsor.id()}'s federation`,
      );
      return;
    }
    this.requestor.requestFederationJoin(sponsor);
  }

  tick(ticks: number): void {
    // No-op — the fanned-out alliance requests each resolve on their own via
    // AllianceRequestExecution-equivalent lifecycle (accept/reject/timeout).
  }

  isActive(): boolean {
    return false;
  }

  activeDuringSpawnPhase(): boolean {
    return false;
  }
}
