import { MutableFederation, Player, PlayerID, Tick } from "./Game";

export class FederationImpl implements MutableFederation {
  private members_: Map<PlayerID, Player> = new Map();
  private joinedAt_: Map<PlayerID, Tick> = new Map();

  constructor(
    private readonly id_: number,
    private readonly foundedAt_: Tick,
    founders: readonly [Player, Player],
  ) {
    for (const p of founders) {
      this.members_.set(p.id(), p);
      this.joinedAt_.set(p.id(), foundedAt_);
    }
  }

  id(): number {
    return this.id_;
  }

  foundedAt(): Tick {
    return this.foundedAt_;
  }

  members(): Player[] {
    return [...this.members_.values()];
  }

  memberSince(player: Player): Tick {
    return this.joinedAt_.get(player.id()) ?? this.foundedAt_;
  }

  addMember(player: Player, joinedAt: Tick): void {
    this.members_.set(player.id(), player);
    this.joinedAt_.set(player.id(), joinedAt);
  }

  removeMember(player: Player): void {
    this.members_.delete(player.id());
    this.joinedAt_.delete(player.id());
  }
}
