import { html, LitElement } from "lit";
import { customElement, state } from "lit/decorators.js";
import { EventBus } from "../../../core/EventBus";
import { Controller } from "../../Controller";
import { SendFederationJoinRequestIntentEvent } from "../../Transport";
import { translateText } from "../../Utils";
import { GameView, PlayerView } from "../../view";

interface RosterRow {
  player: PlayerView;
  color: string;
  tiles: number;
}

@customElement("federation-panel")
export class FederationPanel extends LitElement implements Controller {
  public game: GameView;
  public eventBus: EventBus;

  @state() private expanded = false;
  @state() private active = false;

  createRenderRoot() {
    this.style.position = "fixed";
    this.style.left = "8px";
    this.style.bottom = "8px";
    this.style.zIndex = "500";
    this.style.pointerEvents = "auto";
    return this;
  }

  init() {
    this.active = true;
  }

  tick() {
    if (this.active) this.requestUpdate();
  }

  private toggle() {
    this.expanded = !this.expanded;
  }

  private requestJoin(sponsor: PlayerView) {
    this.eventBus.emit(new SendFederationJoinRequestIntentEvent(sponsor));
  }

  /** Finds an ally who's federated but whose federation I'm not part of and haven't already asked to join. */
  private findEligibleSponsor(me: PlayerView): PlayerView | null {
    return (
      me
        .allies()
        .find(
          (a) =>
            a.federationID() !== null && a.federationID() !== me.federationID(),
        ) ?? null
    );
  }

  private renderRoster(me: PlayerView) {
    const federationID = me.federationID();
    const members: RosterRow[] = this.game
      .playerViews()
      .filter((p) => p.federationID() === federationID)
      .map((p) => ({
        player: p,
        color: p.territoryColor().toHex(),
        tiles: p.numTilesOwned(),
      }))
      .sort((a, b) => b.tiles - a.tiles);

    const validTiles = Math.max(
      1,
      this.game.numLandTiles() - this.game.numTilesWithFallout(),
    );
    const combinedTiles = members.reduce((sum, m) => sum + m.tiles, 0);
    const combinedPct = (combinedTiles / validTiles) * 100;
    const threshold = this.game.config().percentageTilesOwnedToWin();

    return html`
      <div class="p-3 flex flex-col gap-2.5 min-w-64 max-w-80">
        <div class="flex items-center gap-2 text-sm font-bold text-amber-200">
          <span aria-hidden="true">🏛️</span>
          <span>${translateText("federation.title")}</span>
          <span class="ml-auto text-xs font-normal text-zinc-400"
            >${members.length}</span
          >
        </div>

        <div class="flex flex-col gap-1 max-h-40 overflow-y-auto">
          ${members.map(
            (m) => html`
              <div class="flex items-center gap-2 text-xs">
                <span
                  class="w-2.5 h-2.5 rounded-sm shrink-0"
                  style="background:${m.color}"
                ></span>
                <span class="truncate flex-1 text-zinc-100"
                  >${m.player.displayName()}${m.player.isMe()
                    ? html` <span class="text-zinc-500">(${translateText("federation.you")})</span>`
                    : ""}</span
                >
                <span class="tabular-nums text-zinc-300"
                  >${((m.tiles / validTiles) * 100).toFixed(1)}%</span
                >
              </div>
            `,
          )}
        </div>

        <div class="flex flex-col gap-1">
          <div class="flex justify-between text-[11px] text-zinc-400">
            <span>${translateText("federation.combined_territory")}</span>
            <span class="tabular-nums text-zinc-200 font-semibold"
              >${combinedPct.toFixed(1)}% / ${threshold}%</span
            >
          </div>
          <div
            class="relative h-3.5 rounded-sm bg-white/5 border border-white/10 overflow-hidden"
          >
            ${(() => {
              let offset = 0;
              return members.map((m) => {
                const width = (m.tiles / validTiles) * 100;
                const seg = html`<div
                  class="absolute inset-y-0"
                  style="left:${offset}%;width:${width}%;background:${m.color}"
                ></div>`;
                offset += width;
                return seg;
              });
            })()}
            <div
              class="absolute inset-y-0 w-px bg-white/80"
              style="left:${Math.min(100, threshold)}%"
            ></div>
          </div>
        </div>
      </div>
    `;
  }

  private renderPending(me: PlayerView) {
    const pending = me.pendingFederationJoin();
    if (!pending) return html``;
    // pendingFederationJoin stores PlayerIDs; look players up by id directly.
    const byId = (id: string): PlayerView | undefined =>
      this.game.playerViews().find((p) => p.id() === id);

    return html`
      <div class="p-3 flex flex-col gap-2 min-w-64 max-w-80">
        <div class="text-sm font-bold text-amber-200 flex items-center gap-2">
          <span aria-hidden="true">🏛️</span>
          <span>${translateText("federation.request_pending")}</span>
        </div>
        <div class="flex flex-col gap-1">
          ${pending.accepted.map((id) => {
            const p = byId(id);
            return html`<div class="flex items-center justify-between text-xs">
              <span class="text-zinc-100 truncate"
                >${p?.displayName() ?? id}</span
              >
              <span
                class="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-500/80 text-emerald-950"
                >${translateText("federation.status_accepted")}</span
              >
            </div>`;
          })}
          ${pending.targets.map((id) => {
            const p = byId(id);
            return html`<div class="flex items-center justify-between text-xs">
              <span class="text-zinc-100 truncate"
                >${p?.displayName() ?? id}</span
              >
              <span
                class="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-yellow-500/80 text-yellow-950"
                >${translateText("federation.status_pending")}</span
              >
            </div>`;
          })}
          ${pending.declined.map((id) => {
            const p = byId(id);
            return html`<div class="flex items-center justify-between text-xs">
              <span class="text-zinc-100 truncate"
                >${p?.displayName() ?? id}</span
              >
              <span
                class="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-red-500/80 text-white"
                >${translateText("federation.status_declined")}</span
              >
            </div>`;
          })}
        </div>
      </div>
    `;
  }

  private renderEligible(me: PlayerView, sponsor: PlayerView) {
    return html`
      <div class="p-3 flex flex-col gap-2 min-w-64 max-w-80">
        <div class="text-sm font-bold text-amber-200 flex items-center gap-2">
          <span aria-hidden="true">🏛️</span>
          <span
            >${translateText("federation.eligible_notice", {
              name: sponsor.displayName(),
            })}</span
          >
        </div>
        <button
          class="text-xs font-bold px-3 py-1.5 rounded-md bg-amber-500 hover:bg-amber-400 text-amber-950 self-start cursor-pointer"
          @click=${() => this.requestJoin(sponsor)}
        >
          ${translateText("federation.request_federation")}
        </button>
      </div>
    `;
  }

  render() {
    if (!this.active || this.game.inSpawnPhase()) return html``;
    const me = this.game.myPlayer();
    if (!me || !me.isAlive()) return html``;

    const federationID = me.federationID();
    const pending = me.pendingFederationJoin();
    const eligibleSponsor = federationID === null && !pending
      ? this.findEligibleSponsor(me)
      : null;

    if (federationID === null && !pending && !eligibleSponsor) {
      return html``;
    }

    return html`
      <div class="rounded-lg overflow-hidden shadow-lg">
        <button
          class="w-full flex items-center gap-2 px-3 py-1.5 bg-gray-800/92 backdrop-blur-sm text-xs font-semibold text-amber-200 cursor-pointer hover:bg-gray-700/92"
          @click=${() => this.toggle()}
        >
          <span aria-hidden="true">🏛️</span>
          <span
            >${federationID !== null
              ? translateText("federation.title")
              : pending
                ? translateText("federation.request_pending")
                : translateText("federation.request_federation")}</span
          >
          <span class="ml-auto text-zinc-400">${this.expanded ? "▾" : "▸"}</span>
        </button>
        ${this.expanded
          ? html`<div class="bg-gray-800/92 backdrop-blur-sm border-t border-white/5">
              ${federationID !== null
                ? this.renderRoster(me)
                : pending
                  ? this.renderPending(me)
                  : eligibleSponsor
                    ? this.renderEligible(me, eligibleSponsor)
                    : ""}
            </div>`
          : ""}
      </div>
    `;
  }
}
