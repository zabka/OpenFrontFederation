import { AllianceExtensionExecution } from "../src/core/execution/alliance/AllianceExtensionExecution";
import { AllianceRejectExecution } from "../src/core/execution/alliance/AllianceRejectExecution";
import { AllianceRequestExecution } from "../src/core/execution/alliance/AllianceRequestExecution";
import { BreakAllianceExecution } from "../src/core/execution/alliance/BreakAllianceExecution";
import { FederationJoinRequestExecution } from "../src/core/execution/federation/FederationJoinRequestExecution";
import { Game, Player, PlayerType } from "../src/core/game/Game";
import { playerInfo, setup } from "./util/Setup";

let game: Game;
let player1: Player;
let player2: Player;
let player3: Player;
let player4: Player;

function mockAllied(...players: Player[]) {
  for (const p of players) {
    vi.spyOn(p, "canSendAllianceRequest").mockReturnValue(true);
    vi.spyOn(p, "isAlive").mockReturnValue(true);
  }
}

/** Forms a full bilateral alliance between a and b via the normal request/accept flow. */
function allyUp(a: Player, b: Player) {
  mockAllied(a, b);
  game.addExecution(new AllianceRequestExecution(a, b.id()));
  game.executeNextTick();
  game.addExecution(new AllianceRequestExecution(b, a.id()));
  game.executeNextTick();
}

/** Both sides agree to renew a's alliance with b (must already be allied). */
function renew(a: Player, b: Player) {
  game.addExecution(new AllianceExtensionExecution(a, b.id()));
  game.executeNextTick();
  game.addExecution(new AllianceExtensionExecution(b, a.id()));
  game.executeNextTick();
}

describe("Federation", () => {
  beforeEach(async () => {
    game = await setup(
      "ocean_and_land",
      { infiniteGold: true, instantBuild: true, infiniteTroops: true },
      [
        playerInfo("player1", PlayerType.Human),
        playerInfo("player2", PlayerType.Human),
        playerInfo("player3", PlayerType.Human),
        playerInfo("player4", PlayerType.Human),
      ],
    );

    player1 = game.player("player1");
    player2 = game.player("player2");
    player3 = game.player("player3");
    player4 = game.player("player4");
  });

  describe("Founding", () => {
    test("first renewal between two unaffiliated allies founds a federation", () => {
      allyUp(player1, player2);
      expect(player1.federation()).toBeNull();

      renew(player1, player2);

      const fed = player1.federation();
      expect(fed).not.toBeNull();
      expect(player2.federation()).toBe(fed);
      expect(fed!.members().map((p) => p.id()).sort()).toEqual(
        ["player1", "player2"].sort(),
      );
    });

    test("second renewal does not found another federation", () => {
      allyUp(player1, player2);
      renew(player1, player2);
      const fedAfterFirst = player1.federation();
      expect(fedAfterFirst).not.toBeNull();

      renew(player1, player2);
      expect(player1.federation()).toBe(fedAfterFirst);
    });

    test("first renewal does not found a federation if either side is already federated", () => {
      allyUp(player1, player2);
      renew(player1, player2); // player1 + player2 now federated

      allyUp(player1, player3);
      expect(player3.federation()).toBeNull();

      renew(player1, player3);

      // player3 stays unaffiliated: player1 already had a federation, so a
      // brand-new 2-member founding doesn't fire. Joining goes through the
      // sponsor + Request Federation flow instead.
      expect(player3.federation()).toBeNull();
      expect(player1.federation()!.members()).toHaveLength(2);
    });
  });

  describe("Joining", () => {
    beforeEach(() => {
      allyUp(player1, player2);
      renew(player1, player2); // founds a 2-member federation
    });

    test("joining requires accepting the fanned-out request from every other member (sponsor doesn't count twice)", () => {
      allyUp(player3, player1); // player1 sponsors player3

      game.addExecution(
        new FederationJoinRequestExecution(player3, player1.id()),
      );
      game.executeNextTick();

      // Federation has 2 members (player1, player2); the sponsor already
      // counts via the sponsorship alliance, so exactly one fan-out request
      // goes out — to player2.
      expect(player3.federation()).toBeNull();
      const pending = player3.pendingFederationJoin()!;
      expect(pending.targets).toEqual(["player2"]);

      const req = player2
        .incomingAllianceRequests()
        .find((r) => r.requestor() === player3)!;
      req.accept();

      expect(player3.federation()).toBe(player1.federation());
      expect(player1.federation()!.members()).toHaveLength(3);
    });

    test("joining a 3+ member federation requires every other member to accept", () => {
      // Grow to 3 members first.
      allyUp(player3, player1);
      game.addExecution(
        new FederationJoinRequestExecution(player3, player1.id()),
      );
      game.executeNextTick();
      player2
        .incomingAllianceRequests()
        .find((r) => r.requestor() === player3)!
        .accept();
      expect(player1.federation()!.members()).toHaveLength(3);

      // player4 sponsored by player2, must separately win over player1 and player3.
      allyUp(player4, player2);
      mockAllied(player4, player1, player3);

      game.addExecution(
        new FederationJoinRequestExecution(player4, player2.id()),
      );
      game.executeNextTick();

      expect(player4.federation()).toBeNull();
      const pending = player4.pendingFederationJoin();
      expect(pending).not.toBeNull();
      expect(pending!.targets.sort()).toEqual(["player1", "player3"].sort());

      // player1 accepts.
      const req1 = player1
        .incomingAllianceRequests()
        .find((r) => r.requestor() === player4)!;
      req1.accept();
      expect(player4.federation()).toBeNull(); // still waiting on player3

      // player3 accepts -> every request landed, promote to full member.
      const req3 = player3
        .incomingAllianceRequests()
        .find((r) => r.requestor() === player4)!;
      req3.accept();

      expect(player4.federation()).toBe(player1.federation());
      expect(player1.federation()!.members()).toHaveLength(4);
    });

    test("a single decline blocks promotion without rolling back accepted links", () => {
      allyUp(player3, player1);
      game.addExecution(
        new FederationJoinRequestExecution(player3, player1.id()),
      );
      game.executeNextTick();
      player2
        .incomingAllianceRequests()
        .find((r) => r.requestor() === player3)!
        .accept();
      expect(player1.federation()!.members()).toHaveLength(3);

      allyUp(player4, player2);
      mockAllied(player4, player1, player3);
      game.addExecution(
        new FederationJoinRequestExecution(player4, player2.id()),
      );
      game.executeNextTick();

      const req1 = player1
        .incomingAllianceRequests()
        .find((r) => r.requestor() === player4)!;
      req1.accept();

      game.addExecution(new AllianceRejectExecution(player4.id(), player3));
      game.executeNextTick();

      // player4 never becomes a member — that one link just never forms.
      expect(player4.federation()).toBeNull();
      const pending = player4.pendingFederationJoin()!;
      expect(pending.accepted).toEqual(["player1"]);
      expect(pending.declined).toEqual(["player3"]);
      // player1's alliance with player4 still stands — no rollback.
      expect(player1.isAlliedWith(player4)).toBe(true);
    });
  });

  describe("Pruning and dissolution", () => {
    test("a 2-member federation dissolves entirely when its only link expires", () => {
      allyUp(player1, player2);
      renew(player1, player2);
      const alliance = player1.allianceWith(player2)!;

      game.expireAlliance(alliance);

      expect(player1.federation()).toBeNull();
      expect(player2.federation()).toBeNull();
    });

    test("a 2-member federation dissolves entirely on betrayal", () => {
      allyUp(player1, player2);
      renew(player1, player2);

      game.addExecution(new BreakAllianceExecution(player1, player2.id()));
      game.executeNextTick(); // init(): resolves the recipient
      game.executeNextTick(); // tick(): actually breaks the alliance

      expect(player1.federation()).toBeNull();
      expect(player2.federation()).toBeNull();
    });

    /** Fully joins `requestor` into `sponsor`'s federation (fan-out + every other member accepting). */
    function joinFederationFully(requestor: Player, sponsor: Player) {
      allyUp(requestor, sponsor);
      game.addExecution(
        new FederationJoinRequestExecution(requestor, sponsor.id()),
      );
      game.executeNextTick();
      const pending = requestor.pendingFederationJoin();
      for (const targetID of pending?.targets ?? []) {
        game
          .player(targetID)
          .incomingAllianceRequests()
          .find((r) => r.requestor() === requestor)!
          .accept();
      }
    }

    test("in a 3+ member federation, the more recently joined side of a broken link is pruned", () => {
      allyUp(player1, player2);
      renew(player1, player2); // founders: player1, player2

      joinFederationFully(player3, player1); // player3 joins after the founders

      const fed = player1.federation()!;
      expect(fed.members()).toHaveLength(3);

      // The founder/newcomer link (player1 <-> player3) breaks — player3
      // joined more recently, so player3 is pruned, not player1.
      const alliance = player3.allianceWith(player1)!;
      game.expireAlliance(alliance);

      expect(player3.federation()).toBeNull();
      expect(player1.federation()).toBe(fed);
      expect(player2.federation()).toBe(fed);
      expect(fed.members().map((p) => p.id()).sort()).toEqual(
        ["player1", "player2"].sort(),
      );
    });

    test("pruning only affects the federation, not the surviving pairwise alliances", () => {
      allyUp(player1, player2);
      renew(player1, player2);
      joinFederationFully(player3, player1);

      // player3 is also independently allied with player2 (formed as part of
      // the join fan-out above) — unrelated to the link that's about to break.
      expect(player3.isAlliedWith(player2)).toBe(true);

      const alliance = player3.allianceWith(player1)!;
      game.expireAlliance(alliance);

      expect(player3.federation()).toBeNull();
      // The unrelated player3<->player2 alliance is untouched.
      expect(player3.isAlliedWith(player2)).toBe(true);
    });
  });
});
